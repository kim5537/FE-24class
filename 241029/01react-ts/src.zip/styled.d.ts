import "styled-components";

declare module "styled-components" {
  export interface defaultTheme {
    textColor: string;
    bgColor: string;
    accentColor: string;
    cardBgColor: string;
  }
}
