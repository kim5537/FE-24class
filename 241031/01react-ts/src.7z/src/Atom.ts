import { atom } from "recoil";

export interface IToDo {
  id: number;
  text: string;
  category: "TODO" | "DOING" | "DONE";
}

export const toDoState = atom<IToDo[]>({
  key: "toDo",
  default: [], // 투두라는 이름의  식별자를 가진 애는 배열의 형태를 가질 거라고 정의 한 것.
});
