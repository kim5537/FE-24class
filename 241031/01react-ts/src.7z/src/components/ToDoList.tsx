import styled from "styled-components";
import CreateToDo from "./CreateToDo";
import { toDoState } from "../Atom";
import { useRecoilValue } from "recoil";
import ToDo from "./ToDo";

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  gap: 10px;
  justify-content: center;
  align-items: center;
`;

const Title = styled.h1`
  margin-bottom: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid;
`;

const ToDoList = () => {
  const toDos = useRecoilValue(toDoState);
  return (
    <Container>
      <Title>ToDo List</Title>
      <CreateToDo />
      <ul>
        {toDos.map((toDo) => (
          <ToDo key={toDo.id} {...toDo} />
        ))}
      </ul>
    </Container>
  );
};

export default ToDoList;
