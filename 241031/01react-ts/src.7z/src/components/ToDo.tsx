import React from "react";
import { IToDo } from "../Atom";

const ToDo = ({ text }: IToDo) => {
  return <li>{text}</li>;
};

export default ToDo;
